package com.javatechie.spring.mongo.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GolfLoungeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
